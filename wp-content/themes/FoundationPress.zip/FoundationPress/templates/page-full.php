<?php
/*
Template Name: Full Width
*/
get_header(); ?>

<div>
	


<section class="first-section medium-pbxxl">
	

	<div class="row">
		<div class="small-12 large-12 columns" role="main">
			<h1 class="first-section__title">
				De Hollandganger
			</h1>
			<h2 class="first-section__sub">
				Ambachtelijke houtsnijwerken en meubels op maat
			</h2>
		</div>
	</div>

	<a href="#crew">
		<span>
			<i class="fa fa-chevron-down first-section__arrow"></i>
		</span>
	</a>
</section>

<section id="highlights" class="slider-section medium-ptxxl medium-pbxxl small-pbxxl small-ptxxl medium-mbxxl">
	<div class="row">
		<h2 class="slider-section__title">
			Meesterwerken
		</h2>	
	</div>
	<div class="slider medium-mtxxl">
		<div class="slide slide-1">
			<div class="slide-info">
				Maatkast
			</div>
		</div>
		<div class="slide slide-2">
			<div class="slide-info">
				Vijf broden en twee vissen
			</div>
		</div>
		<div class="slide slide-3">
		<div class="slide-info">
			Lambriseringen voor in huis
		</div>
	</div>

</section>




<?php get_footer(); ?>
