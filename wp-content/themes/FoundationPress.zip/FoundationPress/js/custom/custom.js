jQuery(window).on('load', function(){

	jQuery('.icon-menu').click(function(){
		$('body').toggleClass('expand-menu');
	});

	jQuery('.slider').slick();


	jQuery('.right > li').click(function(){
		$('body').removeClass('expand-menu');
	});

	jQuery('.rfbp-post').addClass('medium-6 small-12 columns small-paxl small-pbxl medium-pbxl').height(450);

});

