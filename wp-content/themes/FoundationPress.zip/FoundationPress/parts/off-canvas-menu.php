<?php
/**
 * Template part for off canvas menu
 *
 * @package WordPress
 * @subpackage FoundationPress
 * @since FoundationPress 1.0
 */

?>
<aside class="left-off-canvas-menu">
   <ul class="off-canvas-list">
	
       <ul class="right medium-ptxl">
          <li>Stuur een e-mail naar <a class="name" HREF="hans.valk@dehollandganger.nl">hans.valk@dehollandganger.nl </A>voor meer informatie<</li>
         
        </ul>

	</ul>
</aside>