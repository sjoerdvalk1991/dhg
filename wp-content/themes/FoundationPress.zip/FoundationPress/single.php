<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage FoundationPress
 * @since FoundationPress 1.0
 */

get_header(); ?>

<?php 
	$url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
?>

<section class="first-sec" style="background: linear-gradient( rgba(37, 40, 80, 0.75), rgba(37, 40, 80, 0.75)), url(<?php echo $url ?>); background-size: cover;">
	<div class="row">
		<div class="small-12 large-12 columns" role="main">
		<h1 class="first-sec__title">
			<?php echo get_the_title(); ?>
		</h1>
		

		</div>
	</div>

	<a href="#post">
		<span>
			<i class="fa fa-chevron-down first-sec__arrow"></i>
		</span>
	</a>
</section>

<section id="post" class="poststart-section small-ptxxl">
	<div class="row">
		<div class="medium-8 columns">
			<h2 class="poststart-section__title">
				<?php echo get_the_title(); ?>
			</h2>
			<div class="text-left">
				<?php 
				if ( have_posts() ) : while ( have_posts() ) : the_post();
				  the_content();
				endwhile;
				  
				endif;
				?>
			</div>
		</div>
		<div class="medium-4 columns small-ptxl">
			<div class="medium-pal">
			<?php if(get_field('author')){ ?>

				<h5>Geschreven door <?php the_field('author'); ?></h5>

			<?php } ?>

				<h5><?php the_date(); ?></h5>
			</div>
			
		</div>

</section>


<section id="images">
	<div class="slider-single">
		
		<?php 

		$image = get_field('slide-1');

		if( !empty($image) ): ?>
		<div class="slide">
			<img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
		</div>
		<?php endif; ?>
		
		<?php 

		$image = get_field('slide-2');

		if( !empty($image) ): ?>
		<div class="slide">
			<img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
		</div>
		<?php endif; ?>

		<?php 

		$image = get_field('slide-3');

		if( !empty($image) ): ?>
		<div class="slide">
			<img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
		</div>
		<?php endif; ?>
	</div>
</section>


<section id="related" class="posts-section">
	<div class="row medium-mbxxl medium-mtxxl">

	<h2 class="posts-section__title">Gerelateerde berichten</h2>
	<?php
	global $post;
	$cat_ID=array();
	$categories = get_the_category(); //get all categories for this post
	  foreach($categories as $category) {
	    array_push($cat_ID,$category->cat_ID);
	  }
	  $args = array(
	  'orderby' => 'date',
	  'order' => 'DESC',
		'post_type' => 'post',
		'numberposts' => 8,
		'post__not_in' => array($post->ID),
		'category__in' => $cat_ID
	  ); // post__not_in will exclude the post we are displaying
	    $cat_posts = get_posts($args);
	      foreach($cat_posts as $cat_post) {
				$url = wp_get_attachment_url( get_post_thumbnail_id($cat_post->ID) );
				?>
				<div class="fixed-margin medium-6 large-4 columns end">
					<a href="<?php echo get_permalink($cat_post->ID); ?>">
						<div style="background-image: url(<?php echo $url ?>);" class="post">
							<div class="overlay">
								<h3 class="post-title">
									<?php echo get_the_title($cat_post->ID); ?>
								</h3>	
							</div>
						</div>
					</a>	
				</div> 
			<?php  
	      }
	    
	?>
	</div>
</section>





<?php get_footer(); ?>